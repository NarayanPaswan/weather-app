class AppConstants{
 
  static const String baseURL ="http://api.weatherapi.com/v1/";
  static const String apiKey ="c8dc9e9e9daa47799cf134730231005";
  static const String countryWeather ='baseURL/current.json?key=$apiKey&q=India';
  static const String allCountries = 'https://disease.sh/v3/covid-19/countries';

  

  
}